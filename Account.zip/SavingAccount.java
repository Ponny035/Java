public class SavingAccount extends Account
{
  public SavingAccount(String accountName, int accountNumber, String branch, double balance)
  {
    super( accountName, accountNumber, branch, balance);
  }
  public void withdrawal(double outCome)
  {
    if(outCome<super.getBalance())
    {
      super.setBalance(super.getBalance() - outCome);
      System.out.println("withdrawal approve your blance is :"+ super.getBalance());
    }
  }
}